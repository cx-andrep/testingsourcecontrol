import HomePage from "./components/HomePage/HomePage";

function App() {
  return <HomePage />;
}

export default App;
