import MusicPlayer from "./components/MusicPlayer";

function App() {
  return (
    <div className="App">
      <MusicPlayer />
    </div>
  );
}

export default App;
